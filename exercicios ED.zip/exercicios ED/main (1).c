#include <stdio.h>
#include <stdbool.h>

#define TAMANHO 5 // Defina o tamanho máximo da fila

int fila[TAMANHO];
int frente = -1, final = -1;

// Função para verificar se a fila está vazia
bool vazia() {
    return (frente == -1 && final == -1);
}

// Função para verificar se a fila está cheia
bool cheia() {
    return ((final + 1) % TAMANHO == frente);
}

// Função para exibir todos os elementos da fila
void mostrarFila() {
    if (vazia()) {
        printf("A fila está vazia.\n");
        return;
    }
    int i = frente;
    printf("Elementos na fila: ");
    do {
        i = (i + 1) % TAMANHO;
        printf("%d ", fila[i]);
    } while (i != final);
    printf("\n");
}

// Função para pesquisar se um elemento está na fila
bool pesquisa(int obj) {
    if (vazia()) return false;
    int i = frente;
    do {
        i = (i + 1) % TAMANHO;
        if (fila[i] == obj) return true;
    } while (i != final);
    return false;
}

// Função para retornar o tamanho da fila
int tamanho() {
    if (vazia()) return 0;
    if (final >= frente) return final - frente;
    return (TAMANHO - frente + final + 1);
}

// Função principal para testar as operações da fila
int main() {
    // Exemplo de uso das funções
    printf("Fila vazia? %s\n", vazia() ? "Sim" : "Não");
    printf("Fila cheia? %s\n", cheia() ? "Sim" : "Não");

    mostrarFila();
    printf("Tamanho da fila: %d\n", tamanho());

    // Testando pesquisa
    int elemento = 10;
    printf("Elemento %d está na fila? %s\n", elemento, pesquisa(elemento) ? "Sim" : "Não");

    return 0;
}
